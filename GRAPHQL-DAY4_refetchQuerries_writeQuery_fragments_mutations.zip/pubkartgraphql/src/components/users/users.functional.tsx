import { useQuery } from "@apollo/client";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { GET_ALL_USERS } from "../../graphql/queries";
import UsersModel from "../../models/users.model";
import "./users.styles.css";

type FetchUsersData = {
  users: UsersModel[];
};

export default function UsersFunctional() {
  // Should be Fetching only id and name
  const { loading, error, data } = useQuery<FetchUsersData>(GET_ALL_USERS);

  let snippet;
  if (data?.users?.length) {
    snippet = data?.users?.map(user => (
      <li key={user.id} className="list-group-item">
        <Link className="no-link-text-style" to={`/userdetails/${user.id}`}>
          {" "}
          {user.name}
        </Link>
      </li>
    ));
  } else {
    snippet = (
      <img src="https://i.gifer.com/CVyf.gif" height="200px" width="400px" />
    );
  }

  return (
    <div className="row justify-content-md-center m-4">
      <div className="col-md-4">
        <h2>List of Users</h2>
        <ul className="list-group">{snippet}</ul>
      </div>
    </div>
  );
}
