import React, { Component, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import ProductModel from "../../models/product.model";
import { fetchProductsAsync } from "../../reducers/products.reducer";
import { AppDispatch, RootState } from "../../store/store";
import Product from "../product/product.component";

export default function ProductList() {
  let products = useSelector((store: RootState) => store.products.products);

  let dispatch = useDispatch<AppDispatch>();

  useEffect(() => {
    dispatch(fetchProductsAsync());
  }, []);

  let productsToBeCreated = products?.map(product => (
    <Product key={product.id} productdetails={product} />
  ));
  return (
    <>
      <h1>List Of Products</h1>
      <div className="row">{productsToBeCreated}</div>
    </>
  );
}
