import React from "react";

type Props = {};

export default function SignIn({}: Props) {
  return <h3>Sign In</h3>;
}
