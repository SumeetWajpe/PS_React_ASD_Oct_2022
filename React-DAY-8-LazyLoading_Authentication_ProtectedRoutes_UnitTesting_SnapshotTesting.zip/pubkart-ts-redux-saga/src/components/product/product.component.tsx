import React, { Component } from "react";
import ProductModel from "../../models/product.model";
import Rating from "../rating/rating.component";
import { MdThumbUpAlt } from "react-icons/md";
import { BsFillTrashFill } from "react-icons/bs";
import { Link } from "react-router-dom";
import { deleteProduct, incrementLikes } from "../../reducers/products.reducer";
import { useDispatch } from "react-redux";

type ProductProps = {
  productdetails: ProductModel;
};

const Product: React.FC<ProductProps> = (props: ProductProps) => {
  let dispatch = useDispatch();
  return (
    <div className="col-sm-6 col-md-3 my-1">
      <div className="card">
        <Link to={`/productdetails/${props.productdetails.id}`}>
          <img
            src={props.productdetails.imageUrl}
            alt={props.productdetails.title}
            height="250px"
            width="300px"
            className="card-img-top"
          />
        </Link>
        <div className="card-body">
          <Rating actualStars={props.productdetails.rating} maxStars={5} />
          <h4 className="card-title">{props.productdetails.title}</h4>
          <h5 className="card-text">₹. {props.productdetails.price}</h5>
          <p className="card-text">
            {/* Could be a seperate Badge Component taking props */}
            <span
              className={
                props.productdetails.isAvailable
                  ? "badge bg-success"
                  : "badge bg-danger"
              }
            >
              {props.productdetails.isAvailable == true
                ? "Available"
                : "Unavailable"}
            </span>
          </p>
          <button
            className="btn btn-primary "
            // onClick={this.IncrementLikes.bind(this)}
            onClick={() => dispatch(incrementLikes(props.productdetails.id))}
            aria-label={`${props.productdetails.likes} Likes`}
          >
            <MdThumbUpAlt /> {props.productdetails.likes}
          </button>
          <button
            className="btn btn-danger mx-2"
            onClick={() => dispatch(deleteProduct(props.productdetails.id))}
            aria-label={`Delete a Product`}
          >
            <BsFillTrashFill />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Product;
