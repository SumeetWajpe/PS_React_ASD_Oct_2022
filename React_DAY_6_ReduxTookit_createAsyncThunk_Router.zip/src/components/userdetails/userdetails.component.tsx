import React, { useEffect, useState } from "react";
import { BsFillPhoneFill } from "react-icons/bs";
import { CgWebsite } from "react-icons/cg";
import { AiTwotoneMail } from "react-icons/ai";
import { FaUserAlt } from "react-icons/fa";
import { useParams } from "react-router-dom";
import UsersModel from "../../models/users.model";

type Props = {};

export default function UserDetails({}: Props) {
  let { userid } = useParams();
  let [user, setuser] = useState<UsersModel>();

  useEffect(() => {
    (async () => {
      let res = await fetch(
        "https://jsonplaceholder.typicode.com/users/" + userid,
      );

      if (res.ok) {
        let user: UsersModel = await res.json();
        setuser(user);
      }
    })();
  }, []);
  return (
    <div>
      <h1>User details for Id - {userid}</h1>
      <div className="row justify-content-md-center m-4">
        <div className="col-md-4">
          <ul className="list-group">
            <li className="list-group-item">
              <FaUserAlt color="teal" aria-label="user name" /> | {user?.name}
            </li>
            <li className="list-group-item">
              <AiTwotoneMail color="teal" aria-label="user email" /> |{" "}
              {user?.email}
            </li>
            <li className="list-group-item">
              <BsFillPhoneFill color="teal" aria-label="user phone number" /> |{" "}
              {user?.phone}
            </li>
            <li className="list-group-item">
              <CgWebsite color="teal" aria-label="companywebsite" /> |{" "}
              <a href={`http://www.${user?.website}`}>{user?.website}</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
