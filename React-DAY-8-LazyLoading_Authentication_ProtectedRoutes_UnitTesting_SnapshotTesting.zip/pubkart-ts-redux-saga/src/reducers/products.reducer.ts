import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";
import ProductModel from "../models/product.model";

export type ProductState = {
  products: ProductModel[];
};

const initialState: ProductState = {
  products: [],
};

// New way using redux toolkit
const productsSlice = createSlice({
  name: "products",
  initialState,
  reducers: {
    incrementLikes: (state, action: PayloadAction<number>) => {
      let index = state.products.findIndex(
        product => product.id === action.payload,
      );
      state.products[index].likes++;
      return state;
    },
    deleteProduct: (state, action: PayloadAction<number>) => {
      let index = state.products.findIndex(
        product => product.id === action.payload,
      );
      state.products.splice(index, 1);
      return state;
    },
    addNewProduct: (state, action: PayloadAction<ProductModel>) => {
      console.log(action.payload);
      state.products = [...state.products, action.payload];
      return state;
    },
    setProducts: (state, action: PayloadAction<ProductModel[]>) => {
      state.products = action.payload;
      return state;
    },
  },
});

export const { incrementLikes, deleteProduct, addNewProduct, setProducts } =
  productsSlice.actions;

export default productsSlice.reducer;
