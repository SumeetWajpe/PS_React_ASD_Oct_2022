import { gql } from "@apollo/client";

export const ALL_PRODUCT_FIELDS_FRAGMENT = gql`
  fragment AllProductFields on Product {
    id
    title
    price
    likes
    rating
    imageUrl
    isAvailable
    description
  }
`;

export const ALL_USERS_FIELDS_FRAGMENT = gql`
  fragment AllUsersFields on User {
    id
    username
    name
    email
    address {
      street
      suite
      city
      zipcode
      geo {
        lat
        lng
      }
    }
    phone
    website
    company {
      name
      catchPhrase
      bs
    }
  }
`;
