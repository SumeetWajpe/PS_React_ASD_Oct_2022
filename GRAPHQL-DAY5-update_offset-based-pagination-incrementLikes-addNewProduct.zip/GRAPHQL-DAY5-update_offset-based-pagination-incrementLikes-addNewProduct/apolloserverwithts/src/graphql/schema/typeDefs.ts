const typeDefs = `#graphql
   type Book {
    id:Int
    title: String
    authorId:Int
  }
  type Author {
    id:Int,
    name:String,
    age:Int,
    books:[Book]
  }
  type Product{
     id: ID!,
     title: String,
     price: Int,
     likes: Int,
     rating: Int,
     imageUrl: String,
     isAvailable: Boolean,
     description: String,
  }
  type Geo {
    lat:String,
    lng:String
  }
  type Address{
  street: String,
  suite: String,
  city: String,
  zipcode: String,
  geo: Geo
  }
  type Company{
    name:String,
    catchPhrase:String,
    bs:String
  }
  type User{
    id: ID!,
    username: String,
     name: String,
     email: String,
     address: Address,
     phone: String,
     website: String,
     company: Company, 
  }

 type Query {
    books: [Book]
    book(id:ID!):Book
    author(id:Int):Author
    authors:[Author]
    products:[Product]
    product(id:ID!):Product
    users(limit:Int,offset:Int):[User]
    user(id:ID!):User
  }
  

  type Mutation{
    addBook(id:Int!,title:String!,authorId:Int):Book
    deleteProduct(id:ID!):Product
    addProduct(id: ID!,
     title: String!,
     price: Int!,
     likes: Int,
     rating: Int,
     imageUrl: String,
     isAvailable: Boolean,
     description: String):Product
     incrementLikes(id:ID!):Product
  }
`;
export default typeDefs;
