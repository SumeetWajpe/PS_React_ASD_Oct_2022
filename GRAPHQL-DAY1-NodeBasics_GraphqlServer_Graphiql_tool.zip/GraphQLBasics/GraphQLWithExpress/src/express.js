var express = require("express");
var { graphqlHTTP } = require("express-graphql");
var { buildSchema } = require("graphql");

var schema = buildSchema(`
  type Query {
    hello: String
    courses:[Course]
    course(id:Int!):Course
    trainer:(id:Int!):Trainer
    trainers:[Trainer]
  }
  type Course{
    id:Int
    title:String
    trainer:String
    duration:String
  }

  type Trainer{
    id:Int
    name:String
    age:Int
    isMCT:Boolean
  }
`);

let courses = [
  {
    id: 1,
    title: "React",
    trainer: "Sumeet Wajpe",
    duration: "7 Days",
  },
  {
    id: 2,
    title: "Technical Analysis",
    trainer: "Rachana Ranade",
    duration: "3 Days",
  },
  {
    id: 3,
    title: "Futures And Options",
    trainer: "Samvit Samant",
    duration: "5 Days",
  },
];

var trainers = [
  { id: 1, name: "Sumeet Wajpe", age: 38, isMCT: true },
  { id: 2, name: "Gulshan Sachdev", age: 45, isMCT: false },
  { id: 3, name: "Rachana Ranade", age: 32, isMCT: true },
];

var root = {
  hello: () => "Hello world!",
  courses: () => courses,
  course: args => {
    // data from DB !
    let id = args.id;
    return courses.filter(course => course.id === id)[0];
  },
  trainers: () => trainers,
  trainer: args => {
    let id = args.id;
    return trainers.filter(trainer => trainer.id === id)[0];
  },
};

var app = express();
app.use(
  "/graphql",
  graphqlHTTP({
    schema: schema,
    rootValue: root,
    graphiql: true,
  }),
);
app.listen(4000, () => console.log("Now browse to localhost:4000/graphql"));
