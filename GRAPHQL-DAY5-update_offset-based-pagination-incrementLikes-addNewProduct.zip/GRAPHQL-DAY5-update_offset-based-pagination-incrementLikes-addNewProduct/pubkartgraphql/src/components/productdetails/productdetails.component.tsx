import { useQuery } from "@apollo/client";
import React, { useEffect, useState } from "react";
import { FaArrowCircleLeft } from "react-icons/fa";
import { MdThumbUpAlt } from "react-icons/md";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Get_ALL_PRODUCTS, GET_PRODUCT_BY_ID } from "../../graphql/queries";
import ProductModel from "../../models/product.model";
import Rating from "../rating/rating.component";
import { client } from "../../index";
import { ProductsFetchData } from "../productlist/productlist.component";

type Props = {};
type FetchProductData = {
  product: ProductModel;
};

export default function ProductDetails({}: Props) {
  let navigate = useNavigate();
  let { productid } = useParams();
  const [product, setProduct] = useState<ProductModel>(new ProductModel());
  //1st approach - Fetch Product from the server
  // const { loading, error, data } = useQuery<FetchProductData>(
  //   GET_PRODUCT_BY_ID,
  //   { variables: { id: Number(productid) } },
  // );

  // if (loading) return <strong>Loading...</strong>;
  // if (error) return <strong>Error! ${error.message}</strong>;

  // 2nd Approach - Fetch data from the cache
  useEffect(() => {
    const dataFromCache: ProductsFetchData | null =
      client.readQuery<ProductsFetchData>({
        query: Get_ALL_PRODUCTS,
      });
    const product: ProductModel | undefined = dataFromCache?.products?.find(
      (p: ProductModel) => p.id == Number(productid),
    );
    if (product) {
      setProduct(product);
    }
  }, []);
  return (
    <>
      <button
        className="btn btn-outline-success my-2"
        onClick={() => navigate("/")}
      >
        <FaArrowCircleLeft />
        Go Back
      </button>
      <div className="row my-2">
        <div className="col-md-8">
          <img
            src={product.imageUrl}
            alt={product?.title}
            height="100%"
            width="100%"
          />
        </div>
        <div className="col-md-4  my-5">
          <h3>{product?.title}</h3>
          <Rating actualStars={product?.rating || 0} maxStars={5} />
          <h5 className="my-2">₹. {product?.price}</h5>
          <span
            className={
              product?.isAvailable ? "badge bg-success" : "badge bg-danger"
            }
          >
            {product?.isAvailable == true ? "Available" : "Unavailable"}
          </span>

          <section>{product?.description}</section>
        </div>
      </div>
    </>
  );
}
