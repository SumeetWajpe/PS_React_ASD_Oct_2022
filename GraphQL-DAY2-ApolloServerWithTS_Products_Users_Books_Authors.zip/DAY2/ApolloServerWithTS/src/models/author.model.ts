export class Author {
  constructor(public id: number, public name: string, public age: number) {}
}

const authors: Author[] = [
  { id: 1, name: "Kevin", age: 29 },
  { id: 2, name: "Roger", age: 40 },
];
export default authors;
