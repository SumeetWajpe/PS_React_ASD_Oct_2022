import authors, { AuthorModel } from "../../models/author.model";
import books, { Book } from "../../models/books.model";
import { LogInInput } from "../../models/LogInInput";
import products, { ProductModel } from "../../models/product.model";
import users, { UserModel } from "../../models/user.model";
import { GetMember } from "../helpers/findMember";
import { sortedUsers } from "../helpers/sort";
import jwt from "jsonwebtoken";
import members, { MemberModel } from "../../models/members.model";
import { combineResolvers } from "graphql-resolvers";
import { isAuthenticated } from "./middleware/isAuthenticated";

const resolvers = {
  Query: {
    books: (): Book[] => books,
    book: (_: any, { id }: { id: number }) => {
      return books.find(book => book.id == id);
    },
    author: (parent: any, { id }: { id: number }) => {
      let theAuthor = authors.find(author => author.id == id);
      return theAuthor;
    },
    authors: (): AuthorModel[] => authors,
    products: combineResolvers(isAuthenticated, (): ProductModel[] => products),
    // Offset based Pagination
    // users: (
    //   _: any,
    //   { limit, offset = 0 }: { limit: number; offset: number },
    // ): UserModel[] => {
    //   let usersToBeSent: UserModel[] = [];
    //   if (limit > 0 && offset >= 0) {
    //     usersToBeSent = users.slice(offset, limit + offset);
    //     return usersToBeSent;
    //   }
    //   return users;
    // },
    // Cursor based pagination
    // users: (
    //   _: any,
    //   { limit, cursor }: { limit: number; cursor: number },
    // ): UserModel[] => {
    //   let usersToBeSent: UserModel[] = [];
    //   if (limit > 0 && cursor >= 0) {

    //     const indexMin = sortedUsers.findIndex(user => user.id == cursor);
    //     const indexMax = indexMin + limit;
    //     usersToBeSent = sortedUsers.filter(
    //       (u: UserModel, index: number) =>
    //         index >= indexMin && index < indexMax,
    //     );
    //     return usersToBeSent;
    //   }
    //   return users;
    // },
    users: (_: any, { limit, cursor }: { limit: number; cursor: number }) => {
      let usersToBeSent: UserModel[] = [];
      if (limit > 0 && cursor >= 0) {
        const indexMin = sortedUsers.findIndex(user => user.id == cursor);
        const indexMax = indexMin + limit + 1;
        usersToBeSent = sortedUsers.filter(
          (u: UserModel, index: number) =>
            index >= indexMin && index < indexMax,
        );

        const hasnextPage = usersToBeSent.length > limit;
        const nextCursorId = usersToBeSent[usersToBeSent.length - 1].id;
        usersToBeSent = hasnextPage
          ? usersToBeSent.slice(0, -1)
          : usersToBeSent;
        return {
          usersFeed: usersToBeSent,
          pageInfo: {
            nextPageCursor: hasnextPage ? nextCursorId : null,
            hasnextPage,
          },
        };
      }
      return users;
    },
    product: (_: any, { id }: { id: number }) => {
      let theProduct = products.find(product => product.id == id);
      return theProduct;
    },
    user: (_: any, { id }: { id: number }) => {
      let theUser = users.find(user => user.id == id);
      return theUser;
    },
    member: combineResolvers(
      isAuthenticated,
      (
        _: any,
        { id }: { id: number },
        { email }: { email: string },
      ): MemberModel | undefined => {
        let theMember: MemberModel | undefined = members.find(
          member => member.id == id,
        );
        return theMember;
      },
    ),
  },
  Author: {
    books: (parent: AuthorModel) => {
      console.log(parent);
      return books.filter(book => book.authorId == parent.id);
    },
  },

  Mutation: {
    addBook(parent: any, args: Book): Book {
      books.push(args);
      return args;
    },
    deleteProduct(_: any, { id }: { id: number }) {
      let index = products.findIndex(p => p.id == id);
      let deletedProduct = products.splice(index, 1);
      return deletedProduct[0];
    },
    addProduct(_: any, args: ProductModel) {
      products.push(args);
      return args;
    },
    incrementLikes(_: any, { id }: { id: number }) {
      let theProduct = products.find(p => p.id == id);

      if (theProduct) {
        theProduct.likes++;
      }
      return theProduct;
    },
    login: async (
      _: any,
      { input }: { input: LogInInput },
      { email }: { email: string },
    ) => {
      try {
        //await fetch user from database

        const member: MemberModel = await GetMember(input);

        // generate the token -> sign()
        const token = jwt.sign(
          { email: member?.email },
          process.env.SECRET_KEY_JWT || "mysecretkey",
          { expiresIn: "1d" },
        );

        return { token };
      } catch (error) {
        console.log(error);
      }
    },
  },
};

export default resolvers;
