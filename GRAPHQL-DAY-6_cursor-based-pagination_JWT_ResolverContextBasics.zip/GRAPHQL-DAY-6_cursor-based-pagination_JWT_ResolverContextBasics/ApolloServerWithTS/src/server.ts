import { ApolloServer } from "@apollo/server";
import { startStandaloneServer } from "@apollo/server/standalone";
import typeDefs from "./graphql/schema/typeDefs";
import resolvers from "./graphql/resolvers/resolvers";
import { MyContext } from "./graphql/context/mycontext";

// The ApolloServer constructor requires two parameters: your schema
// definition and your set of resolvers.
const server = new ApolloServer<MyContext>({
  typeDefs,
  resolvers,
});

async function RunApp() {
  const { url } = await startStandaloneServer(server, {
    listen: { port: 4000 },
    context: async () => ({
      email: "test@123",
    }),
  });
  console.log(`🚀  Server ready at: ${url}`);
}

RunApp();
