export interface AuthContext {
  // Context typing
  email: string;
}
