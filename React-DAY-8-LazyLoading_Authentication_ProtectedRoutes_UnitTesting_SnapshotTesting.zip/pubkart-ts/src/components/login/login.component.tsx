import React from "react";
import { Link, NavLink, Outlet } from "react-router-dom";

type Props = {};

export default function Login({}: Props) {
  return (
    <div className="my-3">
      <ul className="nav nav-tabs ">
        <li className="nav-item">
          <NavLink
            className={({ isActive }) =>
              isActive ? "nav-link active" : "nav-link"
            }
            aria-current="page"
            to="/login/signin"
          >
            Sign In
          </NavLink>
        </li>
        <li className="nav-item">
          <NavLink
            to="/login/signup"
            className={({ isActive }) =>
              isActive ? "nav-link active" : "nav-link"
            }
          >
            Sign Up
          </NavLink>
        </li>
      </ul>

      <div
        style={{
          borderBottom: "1px solid lightgrey",
          borderLeft: "1px solid lightgrey",
          borderRight: "1px solid lightgrey",
        }}
      >
        <Outlet />
      </div>
    </div>
  );
}
