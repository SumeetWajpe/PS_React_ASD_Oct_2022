export class MemberModel {
  constructor(
    public id: number,
    public name: string,

    public email: string,
    public password: string,
  ) {}
}

let members: MemberModel[] = [
  {
    id: 1,
    name: "Leanne Graham",
    email: "Sincere@april.biz",
    password: "Bret@123",
  },
  {
    id: 2,
    name: "Ervin Howell",
    email: "Shanna@melissa.tv",
    password: "Ervin@123",
  },
];

export default members;
