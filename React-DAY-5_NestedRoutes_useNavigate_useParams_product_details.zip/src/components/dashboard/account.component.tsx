import React from "react";

type Props = {};

export default function Account({}: Props) {
  return (
    <div>
      <h2>Account Component</h2>
    </div>
  );
}
