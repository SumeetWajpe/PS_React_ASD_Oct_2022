let str = "Hello Typescript"; // Type Inference
// str = 100; // Error
// console.log(str);

let s: string;
let b: boolean;
let o: object;
let arr: string[] = [];
arr[0] = "C++";
arr[1] = "C#";

// let companies = ["IBM", "Accenture", "Sapient", 10, true]; // accepted with Type Inference
// // let companies:string[] = ["IBM", "Accenture", "Sapient", 10,true];// Error

// let cars: Array<string> = new Array<string>("BMW", "AUDI", "TATA");

// let x: any; // avoid
// x = 123;
// x = "Hello";
// x = true;
// x = { name: "X" };
// x = [10, 20, 30];

// // functions

// function Add(x: number, y: number): number | string {
//   if (x == 0) {
//     return "x cannot be zero !";
//   }
//   return x + y;
// }

// let result: number | string = Add(20, 30);

// console.log(result);

// result = "Empty String";

// Arrow Functions
let Square = (x: number): number => x * x;
// Optional parameters
// function PrintBook(author?: string, title?: string, noOfPages?: number) {
//   console.log(author, title, noOfPages);
// }

// PrintBook("Unknown");
// PrintBook(undefined, "Unknown", 100);
// PrintBook("Dr. APJ Abdul Kalam", "Wings Of Fire", 200);

// Default Parameter
// function PrintBook(
//   author: string = "Unknown",
//   title: string = "Unknown",
//   noOfPages: number = 0,
// ) {
//   console.log(author, title, noOfPages);
// }

// PrintBook();
// PrintBook(undefined, "Dummy", 0);
// PrintBook("Dr. APJ Abdul Kalam", "Wings Of Fire", 200);

// Rest Parameters
// function PrintBook(author: string, ...titles: string[]) {
//   console.log(author, titles);
// }

// PrintBook("Dr. APJ Abdul Kalam", "India 2020", "Wings Of Fire");
// PrintBook("XYZ");

// interface IEmp {
//   id: number;
//   salary?: number;
//   getSalary?(): void;
// }

// let emp: IEmp = { name: "Amit", id: 1 };

class Car {
  private id: 1;
  name: string;
  speed: number;

  constructor(name: string = "AUDI", speed: number = 100) {
    this.name = name;
    this.speed = speed;
  }
  accelerate(): string {
    return `The car ${this.name} is running at ${this.speed} kmph !`;
  }
}

// let carObj = new Car();
// carObj.accelerate();

class JamesBondCar extends Car {
  canFly: boolean;
  constructor(name: string, speed: number, canFly: boolean) {
    super(name, speed);
    this.canFly = canFly;
  }
  accelerate(): string {
    return super.accelerate() + " Can it fly ? " + this.canFly;
  }
}
let jbc = new JamesBondCar("Aston Martin", 300, true);
console.log(jbc.accelerate());
// EnhancedClass
class EnhancedCar {
  constructor(public name: string = "BMW", public speed: number = 100) {}
}

var eCarObj = new EnhancedCar();

class IPerson {
  name: string;
  age: number;
}
interface IEmp {
  id: number;
  salary?: number;
  getSalary?(): void;
}
class Emp implements IEmp, IPerson {
  id: number;
  name: string;
  age: number;
  salary: number;
  getSalary() {
    console.log(this.salary);
  }
}

// Generics
var arrayOfStrings = new Array<string>("BMW", "AUDI", "MERC");
var array_cars = new Array<Car>();
array_cars[0] = new Car("Merc", 300);

class Point<T, V> {
  x: T;
  y: V;
}

var point = new Point<string, number>();

var player = { name: "Djokivic", grandslams: 21 };

function PrintPlayerName({ name }: { name: string }) {
  console.log(name);
}

PrintPlayerName(player);

function ReturnAPlayer() {
  return { name: "Djokivic", grandslams: 21 };
}

let { grandslams } = ReturnAPlayer();
let title = "Wings Of Fire ";
let author = "Dr. APJ Abdul Kalam";
let book = { title, author };

// type Aliases

type Book = {
  id: number;
  name: string;
};

let bookObj: Book = { id: 1, name: "XYZ" };

// extensible
interface IABC {
  x: number;
}

interface IPQR extends IABC {
  y: number;
}

class PQR implements IPQR {
  x: number;
  y: number;
}
