import React, { useEffect, useState } from "react";
import { BsFillPhoneFill } from "react-icons/bs";
import { CgWebsite } from "react-icons/cg";
import { AiTwotoneMail } from "react-icons/ai";
import { FaUserAlt } from "react-icons/fa";
import { useParams } from "react-router-dom";
import UsersModel from "../../models/users.model";
import { useQuery } from "@apollo/client";
import { GET_USER_BY_ID } from "../../graphql/queries";

type Props = {};

type FetchUserData = {
  user: UsersModel;
};
// if data is realtime (changing over seconds) the set fetchPolicy to network only
export default function UserDetails({}: Props) {
  let { userid } = useParams();
  const { loading, error, data } = useQuery<FetchUserData>(GET_USER_BY_ID, {
    variables: { id: Number(userid) },
    fetchPolicy: "network-only", // use network (server) to fetch the data
  });

  return (
    <div>
      <h1>User details for Id - {userid}</h1>
      <div className="row justify-content-md-center m-4">
        <div className="col-md-4">
          <ul className="list-group">
            <li className="list-group-item">
              <FaUserAlt color="teal" aria-label="user name" /> |{" "}
              {data?.user?.name}
            </li>
            <li className="list-group-item">
              <AiTwotoneMail color="teal" aria-label="user email" /> |{" "}
              {data?.user?.email}
            </li>
            <li className="list-group-item">
              <BsFillPhoneFill color="teal" aria-label="user phone number" /> |{" "}
              {data?.user?.phone}
            </li>
            <li className="list-group-item">
              <CgWebsite color="teal" aria-label="companywebsite" /> |{" "}
              <a href={`http://www.${data?.user?.website}`}>
                {data?.user?.website}
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
