import { gql } from "@apollo/client";
import {
  ALL_PRODUCT_FIELDS_FRAGMENT,
  ALL_USERS_FIELDS_FRAGMENT,
} from "./fragments";
export const Get_ALL_PRODUCTS = gql`
  ${ALL_PRODUCT_FIELDS_FRAGMENT}
  query GetAllProducts {
    products {
      ...AllProductFields
    }
  }
`;

export const GET_PRODUCT_BY_ID = gql`
  ${ALL_PRODUCT_FIELDS_FRAGMENT}
  query GetProductById($id: ID!) {
    product(id: $id) {
      ...AllProductFields
    }
  }
`;

export const GET_ALL_USERS = gql`
  ${ALL_USERS_FIELDS_FRAGMENT}
  query GetAllUsers {
    users {
      ...AllUsersFields
    }
  }
`;

export const GET_USER_BY_ID = gql`
  ${ALL_USERS_FIELDS_FRAGMENT}
  query GetUserById($id: ID!) {
    user(id: $id) {
      ...AllUsersFields
    }
  }
`;

export const GET_SELECTED_USERS = gql`
  query GetSelectedUsers($offset: Int, $limit: Int) {
    users(offset: $offset, limit: $limit) {
      id
      name
    }
  }
`;
// https://codeshare.io/OdqDdg
