import React from "react";

type Props = {};

export default function Profile({}: Props) {
  return (
    <div>
      <h2>Profile Component</h2>
    </div>
  );
}
