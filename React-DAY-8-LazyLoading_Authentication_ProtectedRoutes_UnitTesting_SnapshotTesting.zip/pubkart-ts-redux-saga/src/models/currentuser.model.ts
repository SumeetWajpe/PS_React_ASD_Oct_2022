export class CurrentUser {
  constructor(
    public name: string = "",
    public password: string = "",
    public isLoggedIn: boolean = false,
  ) {}
}
