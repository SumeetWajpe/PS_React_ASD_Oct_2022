import { useMutation, useQuery } from "@apollo/client";
import React, { ReactNode, useState } from "react";
import { ADD_NEW_BOOK } from "../graphql/mutations";
import { GET_ALL_AUTHORS } from "../graphql/queries";

type Props = {};

function NewBook({}: Props) {
  const [newBook, setNewBook] = useState({ id: "", title: "", authorId: "" });
  const {
    loading: loadingAuthor,
    data: dataAuthor,
    error: errorAuthor,
  } = useQuery(GET_ALL_AUTHORS);
  const [addNewBook, { loading, error, data }] = useMutation(ADD_NEW_BOOK, {
    variables: {
      id: +newBook.id,
      title: newBook.title,
      authorId: +newBook.authorId,
    },
  });

  if (loading) return <strong>Loading...</strong>;
  if (error) return <strong>Error! ${error.message} </strong>;
  let msg: string | ReactNode = "";

  if (data?.addBook?.title == undefined) {
    msg = "";
  } else if (data?.addBook?.title !== "") {
    console.log("Data : " + data?.addBook?.title);

    msg = <p>{data?.addBook?.title} added successfully !</p>;
  }
  return (
    <form
      style={{ margin: "10px" }}
      onSubmit={e => {
        e.preventDefault();
        console.log(newBook);
        addNewBook();
      }}
    >
      <label>
        Book Id :{" "}
        <input
          type="text"
          required
          onChange={e => setNewBook({ ...newBook, id: e.target.value })}
        />{" "}
      </label>
      <br />
      <label>
        Book Title :{" "}
        <input
          type="text"
          required
          onChange={e => setNewBook({ ...newBook, title: e.target.value })}
        />{" "}
      </label>
      <br />
      {/* <label>
        Author Id :{" "}
        <input
          type="text"
          onChange={e => setNewBook({ ...newBook, authorId: e.target.value })}
        />{" "}
      </label> */}
      <label>
        Author :{" "}
        <select
          onChange={e => setNewBook({ ...newBook, authorId: e.target.value })}
        >
          <option>--Select Author--</option>
          {loadingAuthor == false
            ? dataAuthor?.authors?.map((author: any) => (
                <option key={author.id} value={author.id}>
                  {author.name}
                </option>
              ))
            : ""}
        </select>{" "}
      </label>
      <br />
      <button>Add New Book</button>
      {msg}
    </form>
  );
}

export default NewBook;
