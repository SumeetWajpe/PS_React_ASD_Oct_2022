import { ApolloServer, BaseContext } from "@apollo/server";
import { startStandaloneServer } from "@apollo/server/standalone";
import typeDefs from "./graphql/schema/typeDefs";
import resolvers from "./graphql/resolvers/resolvers";
import { MyContext } from "./graphql/context/mycontext";
import { AuthContext } from "./graphql/context/AuthContext";
import { verifyMember } from "./graphql/helpers/verifyMember";

// The ApolloServer constructor requires two parameters: your schema
// definition and your set of resolvers.
const server = new ApolloServer<AuthContext>({
  typeDefs,
  resolvers,
});

async function RunApp() {
  const { url } = await startStandaloneServer(server, {
    listen: { port: 4000 },
    context: async ({ req }: { req: any }) => {
      // console.log("Context..");
      // verify user by validating the token

      try {
        await verifyMember(req);
        return {
          email: req.email,
        };
      } catch (error) {
        console.log(error);
        return {
          email: null,
        };
      }
    },
  });
  console.log(`🚀  Server ready at: ${url}`);
}

RunApp();
