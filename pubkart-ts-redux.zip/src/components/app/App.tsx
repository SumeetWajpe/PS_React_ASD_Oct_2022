import React from "react";
import logo from "./logo.svg";
import { useSelector, useDispatch } from "react-redux";
import { IncrementLikes } from "../../actions/actionCreators";

function App() {
  const dispatch = useDispatch();
  const products = useSelector((store: any) => store.products);
  const users = useSelector((store: any) => store.users);
  // console.log(products);
  // console.log(users);
  return (
    <div>
      Configuring Redux
      <button onClick={() => dispatch(IncrementLikes())}>
        Dispatch (IncrementLikes)
      </button>
      <button>Dispatch (Delete Product)</button>
    </div>
  );
}

export default App;
