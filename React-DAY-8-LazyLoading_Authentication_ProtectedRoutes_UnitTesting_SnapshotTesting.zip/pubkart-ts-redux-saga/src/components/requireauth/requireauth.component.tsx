import React, { ReactNode } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { JsxElement } from "typescript";
import { useAuth } from "../auth/auth";

type Props = {};

function RequireAuth({ children }: { children: ReactNode }): any {
  const authCtx = useAuth();
  const location = useLocation();
  if (!authCtx?.user.isLoggedIn) {
    return <Navigate to="/login/signin" state={{path:location.pathname}} />;
  }
  return children;
}

export default RequireAuth;
