import React from "react";

import { BrowserRouter, Link, Route, Routes } from "react-router-dom";
import NewProductWithReactHookForm from "../newproductwithreacthookform/newproductwithreacthookform";
import ProductDetails from "../productdetails/productdetails.component";
import ProductList from "../productlist/productlist.component";
import UserDetails from "../userdetails/userdetails.component";
import UsersFunctional from "../users/users.functional";

function App() {
  return (
    <BrowserRouter>
      <nav className="navbar navbar-dark bg-dark navbar-expand-lg">
        <div className="container-fluid">
          <Link className="navbar-brand" to="/">
            Pubkart
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link className="nav-link active" aria-current="page" to="/">
                  Products
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" aria-current="page" to="/newproduct">
                  New Product
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/users" className="nav-link">
                  Users
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      <Routes>
        <Route path="/" element={<ProductList />}></Route>
        <Route
          path="/productdetails/:productid"
          element={<ProductDetails />}
        ></Route>
        <Route
          path="/newproduct"
          element={<NewProductWithReactHookForm />}
        ></Route>

        <Route path="/users" element={<UsersFunctional />}></Route>
        <Route path="/userdetails/:userid" element={<UserDetails />}></Route>

        <Route path="*" element={<h1>Something went wrong !</h1>}></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
