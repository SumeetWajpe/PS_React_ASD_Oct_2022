import React, { Component } from "react";
import ProductModel from "../../models/product.model";
import Rating from "../rating/rating.component";
import { MdThumbUpAlt } from "react-icons/md";
import { BsFillTrashFill } from "react-icons/bs";
import { Link } from "react-router-dom";
import { useMutation } from "@apollo/client";
import {
  DELETE_PRODUCT_MUTATION,
  INCREMENT_PRODUCT_LIKES_MUTATION,
} from "../../graphql/mutation";
import { Get_ALL_PRODUCTS } from "../../graphql/queries";

type ProductProps = {
  productdetails: ProductModel;
};

const Product: React.FC<ProductProps> = (props: ProductProps) => {
  const [deleteProduct, { loading, error, data }] = useMutation(
    DELETE_PRODUCT_MUTATION,
    {
      variables: { id: +props.productdetails.id },
      refetchQueries: [{ query: Get_ALL_PRODUCTS }], // to update the cache by executing querries on server (May not be the best way)
    },
  );

  const [
    incrementLikes,
    { loading: likesLoading, error: likesError, data: likesData },
  ] = useMutation(INCREMENT_PRODUCT_LIKES_MUTATION);
  return (
    <div className="col-md-3 my-1">
      <div className="card">
        <Link to={`/productdetails/${props.productdetails.id}`}>
          <img
            src={props.productdetails.imageUrl}
            alt={props.productdetails.title}
            height="250px"
            width="300px"
            className="card-img-top"
          />
        </Link>
        <div className="card-body">
          <Rating actualStars={props.productdetails.rating} maxStars={5} />
          <h4 className="card-title">{props.productdetails.title}</h4>
          <h5 className="card-text">₹. {props.productdetails.price}</h5>
          <p className="card-text">
            {/* Could be a seperate Badge Component taking props */}
            <span
              className={
                props.productdetails.isAvailable
                  ? "badge bg-success"
                  : "badge bg-danger"
              }
            >
              {props.productdetails.isAvailable == true
                ? "Available"
                : "Unavailable"}
            </span>
          </p>
          <button
            className="btn btn-primary "
            onClick={() =>
              incrementLikes({ variables: { id: props.productdetails.id } })
            }
            aria-label={`${props.productdetails.likes} Likes`}
          >
            <MdThumbUpAlt /> {props.productdetails.likes}
          </button>
          <button
            className="btn btn-danger mx-2"
            aria-label={`Delete a Product`}
            onClick={() => deleteProduct()}
          >
            <BsFillTrashFill />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Product;
