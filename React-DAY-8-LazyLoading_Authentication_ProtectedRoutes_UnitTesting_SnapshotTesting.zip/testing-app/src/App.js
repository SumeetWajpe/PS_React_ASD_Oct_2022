import logo from "./logo.svg";
import "./App.css";
import React from "react";

class App extends React.Component {
  constructor() {
    super();
    this.state = { count: 0 };
  }

  render() {
    return (
      <>
        <strong>{this.state.count}</strong>
        <button onClick={() => this.setState({ count: this.state.count + 1 })}>
          ++
        </button>
      </>
    );
  }
}

export default App;
