import { call, put, retry, takeLatest } from "redux-saga/effects";
import axios from "axios";
import ProductModel from "../models/product.model";
import { setProducts } from "../reducers/products.reducer";
import { sagaActions } from "./sagaActions";
import { AnyAction } from "redux";

export type Response = {
  data: any;
  headers: any;
  status: number;
  statusText: string;
  request: any;
  config: any;
};

type Action = {
  type: string;
  payload: ProductModel;
};

const getProducts = () =>
  axios.get<ProductModel[]>("http://localhost:4000/products");

const postProduct = () => axios.post("http://localhost:4000/products");

function* fetchProducts() {
  // make the async call
  try {
    const productsResponse: Response = yield call(getProducts);
    yield put(setProducts(productsResponse.data)); // like dispatch (action)
  } catch (e) {
    //  yield put({ type: "USER_FETCH_FAILED", message: e.message });
    console.log(e);
  }
}

function* fetchProductsWithRetry() {
  try {
    const SECOND = 1000;
    const productsResponse: Response = yield retry(3, 10 * SECOND, getProducts);
    yield put(setProducts(productsResponse.data));
  } catch (error) {
    console.log(error); // dispatching error action
  }
}


export function* rootSaga() {
  //   yield takeLatest(sagaActions.PRODUCTS_FETCH_REQUESTED, fetchProducts);
  yield takeLatest(
    sagaActions.PRODUCTS_FETCH_REQUESTED,
    fetchProductsWithRetry,
  );
}
