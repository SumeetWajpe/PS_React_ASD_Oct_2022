let cacheAssets = ["Index.html", "About.html"];
let cacheName = "v4";
self.addEventListener("install", function (e) {
  console.log("Service Worker : Installed !");
  // configure our cache !
  e.waitUntil(
    caches
      .open(cacheName)
      .then(cache => {
        console.log("Service Worker : Caching files !");
        cache.addAll(cacheAssets);
      })
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", function (e) {
  console.log("Service Worker : Activated !");

  e.waitUntil(
    caches.keys().then(allcaches =>
      allcaches.map(c => {
        if (c !== cacheName) {
          console.log("Service Worker : Deleting old cache !");
          return caches.delete(c);
        }
      }),
    ),
  );
});

self.addEventListener("fetch", function (e) {
  console.log("Fetching resources !");
  e.respondWith(
    fetch(e.request).catch(function () {
      return caches.match(e.request);
    }),
  );
});
