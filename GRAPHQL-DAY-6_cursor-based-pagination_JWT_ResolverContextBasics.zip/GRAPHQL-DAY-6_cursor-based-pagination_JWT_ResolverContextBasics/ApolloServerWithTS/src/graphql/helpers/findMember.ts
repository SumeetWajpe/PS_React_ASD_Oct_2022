import { LogInInput } from "../../models/LogInInput";
import members, { MemberModel } from "../../models/members.model";

export function GetMember(input: LogInInput) {
  return new Promise<MemberModel>((resolve, reject) => {
    resolve(
      members.find(m => m.email == input.email) ||
        new MemberModel(0, "", "", ""),
    ); // check for password
  });
}
