import "./App.css";
import React from "react";
import ListOfProducts from "../productlist/listofproducts.component";

class App extends React.Component {
  render() {
    return (
      <div className="container">
        <h1>Pubkart</h1>
        <ListOfProducts />
      </div>
    );
  }
}

export default App;
