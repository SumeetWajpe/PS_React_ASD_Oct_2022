import React, { useEffect, useState } from "react";
import UsersModel from "../../models/users.model";

export default function UsersFunctional() {
  let [users, setUsers] = useState(new Array<UsersModel>());
  useEffect(() => {
    (async () => {
      let res = await fetch("https://jsonplaceholder.typicode.com/users");

      if (res.ok) {
        let users: UsersModel[] = await res.json();
        setUsers(users);
      }
    })();
  }, []);
  let snippet;
  if (users.length) {
    snippet = users.map(user => <li key={user.id}>{user.name}</li>);
  } else {
    snippet = (
      <img src="https://i.gifer.com/CVyf.gif" height="200px" width="400px" />
    );
  }

  return (
    <div className="row justify-content-md-center m-4">
      <div className="col-md-4">
        <h2>List of Users</h2>
        <ul>{snippet}</ul>
      </div>
    </div>
  );
}
