import { configureStore } from "@reduxjs/toolkit";
import products from "../reducers/products.reducer";
import { users } from "../reducers/users.reducer";
import createSagaMiddleware from "redux-saga";
import { rootSaga } from "../saga/saga";
// create the saga middleware
const sagaMiddleware = createSagaMiddleware();

const store = configureStore({
  reducer: {
    products,
    users,
  },
  middleware: getDefaultMiddleware =>
    getDefaultMiddleware({
      serializableCheck: false,
      thunk: false,
    }).concat(sagaMiddleware),
});

sagaMiddleware.run(rootSaga);

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export default store;
