import React from "react";

type Props = {};

export default function SignUp({}: Props) {
  return <h3>Sign Up</h3>;
}
