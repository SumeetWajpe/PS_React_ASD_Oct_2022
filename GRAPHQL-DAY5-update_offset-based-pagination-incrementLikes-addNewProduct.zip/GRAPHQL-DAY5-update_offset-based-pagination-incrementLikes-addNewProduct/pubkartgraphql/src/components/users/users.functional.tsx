import { useQuery } from "@apollo/client";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { GET_ALL_USERS, GET_SELECTED_USERS } from "../../graphql/queries";
import UsersModel from "../../models/users.model";
import "./users.styles.css";
import { GrFormNext, GrFormPrevious } from "react-icons/gr";
type FetchUsersData = {
  users: UsersModel[];
};

export default function UsersFunctional() {
  const PAGE_SIZE = 4;
  const [page, setPage] = useState(0);
  // Should be Fetching only id and name
  // const { loading, error, data } = useQuery<FetchUsersData>(GET_ALL_USERS);
  const { loading, error, data } = useQuery<FetchUsersData>(
    GET_SELECTED_USERS,
    {
      variables: {
        limit: PAGE_SIZE,
        offset: PAGE_SIZE * page,
      },
    },
  );

  let snippet;
  if (data?.users?.length) {
    snippet = data?.users?.map(user => (
      <li key={user.id} className="list-group-item">
        <Link className="no-link-text-style" to={`/userdetails/${user.id}`}>
          {" "}
          {user.name}
        </Link>
      </li>
    ));
  } else {
    snippet = (
      <img src="https://i.gifer.com/CVyf.gif" height="200px" width="400px" />
    );
  }

  return (
    <>
      <div className="row justify-content-md-center m-4">
        <div className="col-md-4">
          <h2>List of Users</h2>
          <ul className="list-group">{snippet}</ul>
        </div>
      </div>
      <div className="row justify-content-between">
        <div className="col-1">
          <button
            className="btn btn-primary"
            onClick={() => setPage(prev => prev - 1)}
          >
            <GrFormPrevious size={20} />
          </button>
        </div>
        <div className="col-2">Page - {page + 1}</div>
        <div className="col-1">
          <button
            className="btn btn-primary"
            onClick={() => setPage(prev => prev + 1)}
          >
            <GrFormNext size={20} />
          </button>
        </div>
      </div>
    </>
  );
}
