import React from "react";
import { BrowserRouter, Link, Route, Routes } from "react-router-dom";
import AuthProvider from "../auth/auth";

import Error from "../error/error.component";
import Login from "../login/login.component";
import Navbar from "../navbar/navbar.component";
import NewProductWithReactHookForm from "../newproductwithreacthookform/newproductwithreacthookform";
import ProductDetails from "../productdetails/productdetails.component";
import ProductList from "../productlist/productlist.component";
import RequireAuth from "../requireauth/requireauth.component";
import SignIn from "../signin/signin.component";
import SignUp from "../signup/signup.component";
import UserDetails from "../userdetails/userdetails.component";
import UsersFC from "../users/users.functional";

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route
            path="/"
            element={
              <RequireAuth>
                <ProductList />
              </RequireAuth>
            }
          ></Route>
          <Route
            path="/productdetails/:productid"
            element={<ProductDetails />}
          ></Route>
          <Route
            path="/newproduct"
            element={
              <RequireAuth>
                <NewProductWithReactHookForm />
              </RequireAuth>
            }
          ></Route>

          <Route path="/users" element={<UsersFC />}></Route>
          <Route path="/userdetails/:userid" element={<UserDetails />}></Route>

          {/* Nested Routes */}
          {/* <Route path="/dashboard" element={<Dashboard />}>
          <Route path="account" element={<Account />}></Route>
          <Route path="profile" element={<Profile />}></Route>
        </Route> */}
          <Route path="/login" element={<Login />}>
            <Route path="signin" element={<SignIn />}></Route>
            <Route path="signup" element={<SignUp />}></Route>
          </Route>
          <Route path="*" element={<Error />}></Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
