import React from "react";
import { BrowserRouter, Link, Route, Routes } from "react-router-dom";

import Error from "../error/error.component";
import Login from "../login/login.component";
import NewProductWithReactHookForm from "../newproductwithreacthookform/newproductwithreacthookform";
import ProductDetails from "../productdetails/productdetails.component";
import ProductList from "../productlist/productlist.component";
import SignIn from "../signin/signin.component";
import SignUp from "../signup/signup.component";
import UserDetails from "../userdetails/userdetails.component";
import UsersFC from "../users/users.functional";

function App() {
  return (
    <BrowserRouter>
      <nav className="navbar navbar-dark bg-dark navbar-expand-lg">
        <div className="container-fluid">
          <Link className="navbar-brand" to="/">
            Pubkart
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link className="nav-link active" aria-current="page" to="/">
                  Products
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" aria-current="page" to="/newproduct">
                  New Product
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/users" className="nav-link">
                  Users
                </Link>
              </li>

              <li className="nav-item">
                <Link to="/login" className="nav-link">
                  Login
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      <Routes>
        <Route path="/" element={<ProductList />}></Route>
        <Route
          path="/productdetails/:productid"
          element={<ProductDetails />}
        ></Route>
        <Route
          path="/newproduct"
          element={<NewProductWithReactHookForm />}
        ></Route>

        <Route path="/users" element={<UsersFC />}></Route>
        <Route path="/userdetails/:userid" element={<UserDetails />}></Route>

        {/* Nested Routes */}
        {/* <Route path="/dashboard" element={<Dashboard />}>
          <Route path="account" element={<Account />}></Route>
          <Route path="profile" element={<Profile />}></Route>
        </Route> */}
        <Route path="/login" element={<Login />}>
          <Route path="signin" element={<SignIn />}></Route>
          <Route path="signup" element={<SignUp />}></Route>
        </Route>
        <Route path="*" element={<Error />}></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
