import users, { UserModel } from "../../models/user.model";

export const sortedUsers = users.sort(
  (userA: UserModel, userB: UserModel): number => {
    if (userA.id < userB.id) {
      return -1;
    }
    if (userA.id > userB.id) {
      return 1;
    }
    return 0;
  },
);
