import { configureStore } from "@reduxjs/toolkit";
import products from "../reducers/products.reducer";
import { users } from "../reducers/users.reducer";
const store = configureStore({
  reducer: {
    products,
    users,
  },
  middleware: getDefaultMiddleware =>
    getDefaultMiddleware({
      serializableCheck: false,
    }),
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export default store;
