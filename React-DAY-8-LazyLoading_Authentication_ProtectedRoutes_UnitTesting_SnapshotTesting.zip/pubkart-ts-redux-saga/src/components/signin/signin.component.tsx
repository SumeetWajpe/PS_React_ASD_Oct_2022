import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { CurrentUser } from "../../models/currentuser.model";
import { useAuth } from "../auth/auth";
import "./signin.css";
type Props = {};
// validate the form (use React Hook Form)
export default function SignIn({}: Props) {
  const [loginuser, setLoginUser] = useState(new CurrentUser());
  // const ctx = useContext(AuthContext)
  const ctx = useAuth(); // Custom Hook - Usage
  const navigate = useNavigate();
  const location = useLocation();

  const redirectPath = location.state?.path || "/";

  const handleLogin = () => {
    // ?? - if user name and password match the set isLoggedIn to true
    // make api calls to authenticate user
    if (loginuser.name === "admin" && loginuser.password === "admin") {
      let currUser = new CurrentUser(loginuser.name, loginuser.password, true);
      ctx?.login(currUser); //setting context api data
      setLoginUser({ ...loginuser, isLoggedIn: true });
      console.log(currUser);
      navigate(redirectPath, { replace: true });
    }
  };

  return (
    <div className="wrapper fadeInDown">
      <div id="formContent">
        <div className="fadeIn first">
          <img
            src="https://cdn.icon-icons.com/icons2/1378/PNG/512/avatardefault_92824.png"
            id="icon"
            alt="User Icon"
          />
        </div>

        <form>
          <input
            type="text"
            id="login"
            className="fadeIn second"
            name="login"
            placeholder="username"
            onChange={e => setLoginUser({ ...loginuser, name: e.target.value })}
          />
          <input
            type="text"
            id="password"
            className="fadeIn third"
            name="login"
            placeholder="password"
            onChange={e =>
              setLoginUser({ ...loginuser, password: e.target.value })
            }
          />
          <input
            type="button"
            className="fadeIn fourth"
            value="Sign In"
            onClick={handleLogin}
          />
        </form>

        <div id="formFooter">
          <a className="underlineHover" href="/login">
            Forgot Password?
          </a>
        </div>
      </div>
    </div>
  );
}
