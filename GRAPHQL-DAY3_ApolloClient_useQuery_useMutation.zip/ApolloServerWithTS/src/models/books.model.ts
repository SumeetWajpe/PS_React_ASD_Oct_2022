export class Book {
  constructor(
    public id: number,
    public title: string,
    public authorId: number,
  ) {}
}

// from db
let books: Book[] = [
  { id: 1, title: "The Awakening", authorId: 1 },
  {
    id: 2,
    title: "City of Glass",
    authorId: 2,
  },
  {
    id: 3,
    title: "Who Moved My Cheese",
    authorId: 2,
  },
];

export default books;
