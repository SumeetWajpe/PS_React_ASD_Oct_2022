import { gql } from "@apollo/client";
import { ALL_PRODUCT_FIELDS_FRAGMENT } from "./fragments";

export const DELETE_PRODUCT_MUTATION = gql`
  mutation DeleteProductMutation($id: ID!) {
    deleteProduct(id: $id) {
      title
    }
  }
`;

export const ADD_NEW_PRODUCT_MUTATION = gql`
  ${ALL_PRODUCT_FIELDS_FRAGMENT}
  mutation AddNewProductMutation(
    $productId: ID!
    $title: String!
    $price: Int!
    $likes: Int
    $rating: Int
    $imageUrl: String
    $isAvailable: Boolean
    $description: String
  ) {
    addProduct(
      id: $productId
      title: $title
      price: $price
      likes: $likes
      rating: $rating
      imageUrl: $imageUrl
      isAvailable: $isAvailable
      description: $description
    ) {
      ...AllProductFields
    }
  }
`;

export const INCREMENT_PRODUCT_LIKES_MUTATION = gql`
  mutation IncrementProductLikes($id: ID!) {
    incrementLikes(id: $id) {
      id
      title
    }
  }
`;
