import { gql } from "@apollo/client";

export const GET_BOOKS_WITH_TITLES = gql`
  query GetBooksWithTitles {
    books {
      title
    }
  }
`;

export const GET_BOOK_WITH_ID = gql`
  query GetBookWithId($bookId: ID!) {
    book(id: $bookId) {
      title
    }
  }
`;

export const GET_ALL_AUTHORS = gql`
  query GetAuthors {
    authors {
      id
      name
    }
  }
`;
