const PI: number = 3.14;
// PI = 3.145565; // Error - If Error with no Emit flag .js will not be created !
var Add = (x: number, y: number) => x + y;
