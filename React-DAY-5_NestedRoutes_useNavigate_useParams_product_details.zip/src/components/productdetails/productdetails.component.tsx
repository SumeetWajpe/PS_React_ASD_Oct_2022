import React, { useEffect, useState } from "react";
import { FaArrowCircleLeft } from "react-icons/fa";
import { Link, useNavigate, useParams } from "react-router-dom";
import ProductModel from "../../models/product.model";
import Rating from "../rating/rating.component";

type Props = {};

export default function ProductDetails({}: Props) {
  let navigate = useNavigate();
  let { productid } = useParams();
  let [product, setProduct] = useState<ProductModel>();

  useEffect(() => {
    (async () => {
      let res = await fetch("http://localhost:4000/products/" + productid);

      if (res.ok) {
        let productResponse: ProductModel = await res.json();
        setProduct(productResponse);
      }
    })();
  }, []);
  return (
    <>
      <button
        className="btn btn-outline-success my-2"
        // onClick={() => navigate("/", { replace: true })}
        onClick={() => navigate("/")}
      >
        <FaArrowCircleLeft /> {/* <Link to="/" style={{ color: "black" }}> */}
        Go Back
        {/* </Link> */}
      </button>
      <div className="row my-2">
        <div className="col-md-8">
          <img
            src={product?.imageUrl}
            alt={product?.title}
            height="100%"
            width="100%"
          />
        </div>
        <div className="col-md-4  my-5">
          <h3>{product?.title}</h3>
          <Rating actualStars={product?.rating || 0} maxStars={5} />
          <h5 className="my-2">₹. {product?.price}</h5>
          <span
            className={
              product?.isAvailable ? "badge bg-success" : "badge bg-danger"
            }
          >
            {product?.isAvailable == true ? "Available" : "Unavailable"}
          </span>
          <section>{product?.description}</section>
        </div>
      </div>
    </>
  );
}
