import React from "react";

import Rating from "../rating/rating.component";
import { MdThumbUpAlt } from "react-icons/md";
import { BsFillTrashFill } from "react-icons/bs";

class Product extends React.Component {
  render() {
    return (
      <div className="col-md-3 my-1">
        <div className="card" style={{ width: "18rem" }}>
          <img
            src={this.props.productdetails.imageUrl}
            alt={this.props.productdetails.title}
            height="250px"
            width="300px"
            className="card-img-top"
          />
          <div className="card-body">
            <Rating
              actualStars={this.props.productdetails.rating}
              maxStars={5}
            />
            <h4 className="card-title">{this.props.productdetails.title}</h4>
            <h5 className="card-text">₹. {this.props.productdetails.price}</h5>
            <p className="card-text">
              {/* Could be a seperate Badge Component taking props */}
              <span
                className={
                  this.props.productdetails.isAvailable == "Available"
                    ? "badge bg-success"
                    : "badge bg-danger"
                }
              >
                {this.props.productdetails.isAvailable}
              </span>
            </p>
            <button className="btn btn-primary ">
              <MdThumbUpAlt /> {this.props.productdetails.likes}
            </button>
            <button className="btn btn-danger mx-2">
              <BsFillTrashFill />
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export default Product;
