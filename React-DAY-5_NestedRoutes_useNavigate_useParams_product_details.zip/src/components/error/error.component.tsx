import React from "react";

type Props = {};

export default function Error({}: Props) {
  return (
    <div className="row justify-content-md-center m-4">
      <h1>OOPS !Something went wrong !</h1>
      <img
        src="https://static.s4be.cochrane.org/app/uploads/2017/04/shutterstock_531145954.jpg"
        alt="Something went wrong !"
      />
    </div>
  );
}
