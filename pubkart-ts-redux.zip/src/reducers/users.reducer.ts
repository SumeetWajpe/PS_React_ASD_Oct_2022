export function users(store: any = [{ id: 1, name: "Dummy" }], action: any) {
  switch (action.type) {
    case "DELETE_USER":
      console.log("Within users reducer !");
      return store; // should be update store data;

    default:
      return store;
  }
}
