export class ProductModel {
  constructor(
    public id: number,
    public title: string,
    public price: number,
    public likes: number,
    public rating: number,
    public imageUrl: string,
    public isAvailable: boolean,
    public description: string,
  ) {}
}

let products: ProductModel[] = [
  {
    id: 1,
    title: "MacBook Pro",
    price: 250000,
    rating: 5,
    isAvailable: true,
    imageUrl:
      "https://www.apple.com/newsroom/images/tile-images/Apple_macbookpro-13-inch_screen_05042020.jpg.og.jpg?202208151956",

    likes: 100,
    description:
      "The most powerful MacBook Pro ever is here. With the blazing-fast M1 Pro or M1 Max chip — the first Apple silicon designed for pros — you get groundbreaking performance and amazing battery life. Add to that a stunning Liquid Retina XDR display, the best camera and audio ever in a Mac notebook, and all the ports you need. The first notebook of its kind, this MacBook Pro is a beast.",
  },
  {
    id: 2,
    title: "MacBook Air",
    price: 200000,
    rating: 4,
    isAvailable: false,
    imageUrl:
      "https://media.croma.com/image/upload/v1655189327/Croma%20Assets/Computers%20Peripherals/Laptop/Images/256712_bjdqif.png",
    likes: 200,
    description:
      "Redesigned around the next-generation M2 chip, MacBook Air is strikingly thin and brings exceptional speed and power efficiency within its durable all‑aluminium enclosure. It’s the ultra-fast, ultra-capable laptop that lets you work, play or create just about anything — anywhere.",
  },
  {
    id: 3,
    title: "iPhone",
    price: 100000,
    rating: 4,
    isAvailable: true,
    imageUrl: "https://m.media-amazon.com/images/I/61AwGDDZd3L._SX522_.jpg",
    likes: 200,
    description:
      "The all-new iPhone 14 Pro and iPhone 14. Buy now. Your photo. Your font. Your widgets. Your iPhone. Ceramic Shield. iOS 16. All-day battery life. Accessibility features. Services: No-contact free delivery, EMI available, Shop with Specialists.",
  },
  {
    id: 4,
    title: "Apple Airpods",
    price: 30000,
    rating: 4,
    isAvailable: true,
    imageUrl:
      "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/MME73?wid=2000&hei=2000&fmt=jpeg&qlt=95&.v=1632861342000",
    likes: 200,
    description:
      "AirPods deliver an unparalleled wireless headphone experience, from magical setup to high-quality sound. Available with free engraving.AirPods deliver an unparalleled wireless headphone experience, from magical setup to high-quality sound. Available with free engraving.",
  },
  {
    id: 5,
    title: "Apple Charger",
    price: 25000,
    rating: 3,
    isAvailable: false,
    imageUrl:
      "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/MJWY3?wid=890&hei=890&fmt=jpeg&qlt=90&.v=1625613219000",
    likes: 200,
    description:
      "Find cables, charging docks and battery cases for Apple devices. Charge and sync up Mac, iPhone, iPod, iPad and Watch. Buy online and get free delivery.Find cables, charging docks and battery cases for Apple devices. Charge and sync up Mac, iPhone, iPod, iPad and Watch. Buy online and get free delivery.",
  },
];

export default products;
