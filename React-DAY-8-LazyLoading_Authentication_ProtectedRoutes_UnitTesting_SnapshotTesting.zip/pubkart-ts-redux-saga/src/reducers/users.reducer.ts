import UsersModel from "../models/users.model";

export function users(store: UsersModel[] = [], action: any) {
  switch (action.type) {
    case "DELETE_USER":
      console.log("Within users reducer !");
      console.log(store);
      return store; // should be update store data;

    default:
      return store;
  }
}
