import React from "react";
import { IoMdLogOut } from "react-icons/io";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/auth";

type Props = {};

const Logout = (props: Props) => {
  const authCtx = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    authCtx?.logout();
    navigate("/", { replace: true });
  };

  return (
    <div>
      <strong className="text-warning"> Welcome {authCtx?.user.name} !</strong>{" "}
      <button type="button" className="btn btn-primary" onClick={handleLogout}>
        Logout <IoMdLogOut />
      </button>
    </div>
  );
};

export default Logout;
