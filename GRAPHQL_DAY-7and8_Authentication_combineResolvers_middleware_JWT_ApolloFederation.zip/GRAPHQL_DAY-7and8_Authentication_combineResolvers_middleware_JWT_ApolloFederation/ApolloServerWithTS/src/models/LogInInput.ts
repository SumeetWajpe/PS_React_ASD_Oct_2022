export class LogInInput {
  constructor(public email: string, public password: string) {}
}
