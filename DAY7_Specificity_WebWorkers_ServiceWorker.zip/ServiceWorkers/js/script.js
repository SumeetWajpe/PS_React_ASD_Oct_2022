if ("serviceWorker" in navigator) {
  window.addEventListener("load", function () {
    navigator.serviceWorker
      .register("serviceworker.js")
      .then(() => console.log("Service Worker : Registered successfully !"))
      .catch(err => console.log("Service worker : Registration failed !"));
  });
}
