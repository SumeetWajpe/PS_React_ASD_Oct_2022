import { configureStore } from "@reduxjs/toolkit";
import { products } from "../reducers/products.reducer";
import { users } from "../reducers/users.reducer";
const store = configureStore({
  reducer: {
    products,
    users,
  },
});

export default store;
