import React from "react";
import logo from "../logo.svg";
import BooksList from "./Book.component";
import BookWithId from "./BookWithId.component";
import NewBook from "./NewBook.component";

function App() {
  return (
    <div>
      {/* <BooksList /> */}
      {/* <BookWithId /> */}
      <NewBook />
    </div>
  );
}

export default App;
