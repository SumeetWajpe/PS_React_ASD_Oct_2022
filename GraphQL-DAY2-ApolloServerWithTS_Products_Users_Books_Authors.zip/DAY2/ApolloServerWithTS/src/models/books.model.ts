export class Book {
  constructor(public title: string, public authorId: number) {}
}

// from db
let books: Book[] = [
  {
    title: "The Awakening",
    authorId: 1,
  },
  {
    title: "City of Glass",
    authorId: 2,
  },
  {
    title: "Who Moved My Cheese",
    authorId: 2,
  },
];

export default books;
