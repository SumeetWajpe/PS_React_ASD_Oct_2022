import { useQuery } from "@apollo/client";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { GET_ALL_USERS, GET_SELECTED_USERS } from "../../graphql/queries";
import UsersModel from "../../models/users.model";
import "./users.styles.css";
import { GrFormNext, GrFormPrevious } from "react-icons/gr";
type FetchUsersData = {
  users: UsersModel[];
};

export default function UsersFunctional() {
  const PAGE_SIZE = 4;
  const [page, setPage] = useState(0);
  const [cursor, setCursor] = useState(1);
  // Should be Fetching only id and name
  // const { loading, error, data } = useQuery<FetchUsersData>(GET_ALL_USERS);
  const { loading, error, data } = useQuery(GET_SELECTED_USERS, {
    variables: {
      limit: PAGE_SIZE,
      cursor: cursor, // cursor
    },
  });

  let snippet;
  if (data?.users?.usersFeed?.length) {
    snippet = data?.users?.usersFeed?.map((user: UsersModel) => (
      <li key={user.id} className="list-group-item">
        <Link className="no-link-text-style" to={`/userdetails/${user.id}`}>
          {" "}
          {user.name}
        </Link>
      </li>
    ));
  } else {
    snippet = (
      <img src="https://i.gifer.com/CVyf.gif" height="200px" width="400px" />
    );
  }

  return (
    <>
      <div className="row justify-content-md-center m-4">
        <div className="col-md-4">
          <h2>List of Users</h2>
          <ul className="list-group">
            {data?.users?.usersFeed?.map((user: UsersModel) => (
              <li key={user.id} className="list-group-item">
                <Link
                  className="no-link-text-style"
                  to={`/userdetails/${user.id}`}
                >
                  {" "}
                  {user.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="row justify-content-between">
        <div className="col-1">
          <button
            className="btn btn-primary"
            onClick={() => {
              setPage(prev => prev - 1);
              setCursor(cursor - PAGE_SIZE);
            }}
          >
            <GrFormPrevious size={20} />
          </button>
        </div>
        <div className="col-2">Page - {page + 1}</div>
        <div className="col-1">
          <button
            className="btn btn-primary"
            disabled={!data?.users?.pageInfo?.hasnextPage}
            onClick={() => {
              setPage(prev => prev + 1);
              setCursor(data?.users?.pageInfo?.nextPageCursor);
            }}
          >
            <GrFormNext size={20} />
          </button>
        </div>
      </div>
    </>
  );
}
