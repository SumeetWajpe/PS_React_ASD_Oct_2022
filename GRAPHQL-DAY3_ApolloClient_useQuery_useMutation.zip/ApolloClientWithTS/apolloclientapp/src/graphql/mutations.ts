import { gql } from "@apollo/client";

export const ADD_NEW_BOOK = gql`
  mutation AddNewBook($id: Int!, $title: String!, $authorId: Int) {
    addBook(id: $id, title: $title, authorId: $authorId) {
      title
    }
  }
`;
