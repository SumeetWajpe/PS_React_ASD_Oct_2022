import { useQuery } from "@apollo/client";
import React, { useState } from "react";
import { idText } from "typescript";
import { GET_BOOK_WITH_ID } from "../graphql/queries";

type Props = {};

export default function BookWithId({}: Props) {
  const [bookId, setBookId] = useState("");
  const { error, loading, data } = useQuery(GET_BOOK_WITH_ID, {
    variables: { bookId: +bookId },
  });
  if (loading) return <strong>Loading...</strong>;
  if (error) return <strong>Error! ${error.message} </strong>;

  return (
    <>
      <label>
        Book Id :{" "}
        <input
          type="text"
          placeholder="Book Id"
          onChange={e => setBookId(e.target.value)}
          value={bookId}
        />
      </label>
      <h2>{data?.book?.title}</h2>
    </>
  );
}
