import React from "react";
import { FaStar } from "react-icons/fa";
import { FiStar } from "react-icons/fi";

export default function Rating(props) {
  return (
    <div>
      {[...new Array(props.maxStars)].map((arr, index) => {
        return index < props.actualStars ? (
          <FaStar color="orange" size="1.3em" />
        ) : (
          <FiStar color="orange" size="1.3em" />
        );
      })}
    </div>
  );
}
