import { ApolloServer } from "apollo-server";
import { buildSubgraphSchema } from "@apollo/subgraph";
import { typeDefs } from "./schema";

const reviews = [
  {
    id: 1,
    rating: 4,
    content: "The best laptop !",
    productId: 1,
  },
  {
    id: 2,
    rating: 5,
    content: "The best performing laptop !",
    productId: 2,
  },
  {
    id: 3,
    rating: 3,
    content: "The best phone !",
    productId: 3,
  },
];

const resolvers = {
  Query: {
    review: (_, { id }) => {
      return reviews.find(review => review.id == id);
    },
  },

  Product: {
    reviews(product) {
      return reviews.filter(review => review.productId == product.id);
    },
  },

  Review: {
    product: review => {
      console.log(review);
      return {
        __typename: "Product",
        id: +review.productId,
      };
    },
  },
};

const server = new ApolloServer({
  schema: buildSubgraphSchema({ typeDefs, resolvers }),
});

server
  .listen({ port: 4002 })
  .then(() => console.log("product server running @ 4002 !"));
