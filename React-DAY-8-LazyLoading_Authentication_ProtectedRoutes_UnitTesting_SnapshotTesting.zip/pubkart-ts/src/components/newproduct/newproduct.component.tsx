import React, { useState } from "react";
import { IoMdAddCircle } from "react-icons/io";
import ProductModel from "../../models/product.model";
type NewProductProps = {
  addAProduct?: (newproduct: ProductModel) => void;
};

export default function NewProduct(props: NewProductProps) {
  let [newproduct, setNewProduct] = useState<ProductModel>(
    new ProductModel(0, "", 0, 0, 0, "", false, ""),
  );
  return (
    <div className="row justify-content-md-center m-4">
      <form className="col-md-4 alert alert-secondary">
        <h2>New Product</h2>
        <label htmlFor="txtProductId">Id : </label>
        <input
          type="number"
          id="txtProductId"
          className="form-control"
          onChange={e => {
            setNewProduct({ ...newproduct, id: +e.target.value });
          }}
        />
        <label htmlFor="txtProductName">Title : </label>
        <input
          type="text"
          id="txtProductName"
          className="form-control"
          onChange={e => {
            setNewProduct({ ...newproduct, title: e.target.value });
          }}
        />
        <label htmlFor="txtProductPrice">Price : </label>
        <input
          type="number"
          id="txtProductPrice"
          className="form-control"
          onChange={e => {
            setNewProduct({ ...newproduct, price: +e.target.value });
          }}
        />
        <label htmlFor="txtProductLikes">Likes : </label>
        <input
          type="number"
          id="txtProductLikes"
          className="form-control"
          onChange={e => {
            setNewProduct({ ...newproduct, likes: +e.target.value });
          }}
        />
        <label htmlFor="txtProductRating">Rating : </label>
        <input
          type="number"
          id="txtProductRating"
          className="form-control"
          onChange={e => {
            setNewProduct({ ...newproduct, rating: +e.target.value });
          }}
        />
        <label htmlFor="txtProductImage">Image URL : </label>
        <input
          type="text"
          id="txtProductImage"
          className="form-control"
          onChange={e => {
            setNewProduct({ ...newproduct, imageUrl: e.target.value });
          }}
        />
        <label htmlFor="txtProductDescription">Description : </label>
        <input
          type="text"
          id="txtProductDescription"
          className="form-control"
          onChange={e => {
            setNewProduct({ ...newproduct, description: e.target.value });
          }}
        />
        <div className="my-2">
          <input
            type="radio"
            id="rdbAvailable"
            name="availibility"
            className="form-check-input"
          />{" "}
          <label htmlFor="rdbAvailable">Available</label>
          {"    "}
          <input
            type="radio"
            id="rdbUnAvailable"
            name="availibility"
            className="form-check-input"
          />{" "}
          <label htmlFor="rdbUnAvailable">Unavailable</label>
        </div>
        <button type="submit" className="btn btn-success my-2">
          Add New Product <IoMdAddCircle />
        </button>
      </form>
    </div>
  );
}
