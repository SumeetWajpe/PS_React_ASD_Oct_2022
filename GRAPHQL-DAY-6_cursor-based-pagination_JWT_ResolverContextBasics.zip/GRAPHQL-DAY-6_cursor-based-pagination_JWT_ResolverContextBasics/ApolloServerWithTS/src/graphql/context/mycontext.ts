export interface MyContext {
  // Context typing
  email: string;
}
