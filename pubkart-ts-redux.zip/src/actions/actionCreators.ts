const PRODUCT_INCREMENT_LIKES = "PRODUCT_INCREMENT_LIKES";

export function IncrementLikes() {
  return { type: PRODUCT_INCREMENT_LIKES };
}

export function AddProduct() {
  return { type: "ADD_PRODUCT" };
}

export function DeleteProduct() {
  return { type: "DELETE_PRODUCT" };
}

export function DeleteUser() {
  return { type: "DELETE_USER" };
}
