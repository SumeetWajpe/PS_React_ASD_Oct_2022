import authors, { AuthorModel } from "../../models/author.model";
import books, { Book } from "../../models/books.model";
import products, { ProductModel } from "../../models/product.model";
import users, { UserModel } from "../../models/user.model";

const resolvers = {
  Query: {
    books: (): Book[] => books,
    book: (_: any, { id }: { id: number }) => {
      return books.find(book => book.id == id);
    },
    author: (parent: any, { id }: { id: number }) => {
      let theAuthor = authors.find(author => author.id == id);
      return theAuthor;
    },
    authors: (): AuthorModel[] => authors,
    products: (): ProductModel[] => products,
    users: (): UserModel[] => users,
    product: (_: any, { id }: { id: number }) => {
      let theProduct = products.find(product => product.id == id);
      return theProduct;
    },
    user: (_: any, { id }: { id: number }) => {
      let theUser = users.find(user => user.id == id);
      return theUser;
    },
  },
  Author: {
    books: (parent: AuthorModel) => {
      console.log(parent);
      return books.filter(book => book.authorId == parent.id);
    },
  },

  Mutation: {
    addBook(parent: any, args: Book): Book {
      books.push(args);
      return args;
    },
  },
};

export default resolvers;
