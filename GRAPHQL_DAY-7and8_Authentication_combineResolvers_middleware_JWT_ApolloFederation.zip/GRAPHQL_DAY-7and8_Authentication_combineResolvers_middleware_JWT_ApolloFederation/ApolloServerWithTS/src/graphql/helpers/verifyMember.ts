import jwt from "jsonwebtoken";
export const verifyMember = async (req: any) => {
  try {
    req.email = null;
    const bearerHeader: string = req.headers.authorization;
    if (bearerHeader) {
      const token = bearerHeader.split(" ")[1];
      // console.log(token);
      const payload: any = jwt.verify(
        token,
        process.env.SECRET_KEY_JWT || "mysecretkey",
      );
      req.email = payload.email;
    }
    // Not the best choice for checking as it denies all request (including signup/login)
    // if (!req.email) {
    //   throw new Error("Access Denied !");
    // }
  } catch (error) {
    // handle the error
    throw error; // don't use in prod | only for testing
  }
};
