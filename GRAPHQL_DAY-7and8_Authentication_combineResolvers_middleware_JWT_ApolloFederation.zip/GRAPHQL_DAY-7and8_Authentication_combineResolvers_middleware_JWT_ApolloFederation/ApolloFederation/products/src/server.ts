import { ApolloServer } from "apollo-server";
import { buildSubgraphSchema } from "@apollo/subgraph";
import { typeDefs } from "./schema";

const products = [
  {
    id: 1,
    title: "Macbook Pro",
    price: 250000,
    description: "Used for professional grade work with high performance !",
    categoryId: 2,
  },
  {
    id: 2,
    title: "Macbook Air",
    price: 200000,
    description: "Used for professional/personal work with great performance !",
    categoryId: 2,
  },
  {
    id: 3,
    title: "iPhone",
    price: 100000,
    description: "Awesome phone !",
    categoryId: 2,
  },
  {
    id: 4,
    title: "Fanta",
    price: 100,
    description: "Delicious orange cold drink !",
    categoryId: 1,
  },
];

const categories = [
  {
    id: 1,
    title: "Food",
  },
  {
    id: 2,
    title: "Electronics",
  },
];

const resolvers = {
  Query: {
    product: (_, { id }) => {
      return products.find(product => product.id == id);
    },
  },
  Product: {
    category(product) {
      return categories.find(category => category.id == product.categoryId);
    },
    __resolveReference(product) {
      console.log(product);
      return products.find(p => p.id == product.id);
    },
  },
};

const server = new ApolloServer({
  schema: buildSubgraphSchema({ typeDefs, resolvers }),
});

server
  .listen({ port: 4001 })
  .then(() => console.log("product server running @ 4001 !"));
