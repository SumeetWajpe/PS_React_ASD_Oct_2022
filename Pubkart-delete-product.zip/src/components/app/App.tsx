import React from "react";

import ProductList from "../productlist/productlist.component";

function App() {
  return <ProductList />;
}

export default App;
