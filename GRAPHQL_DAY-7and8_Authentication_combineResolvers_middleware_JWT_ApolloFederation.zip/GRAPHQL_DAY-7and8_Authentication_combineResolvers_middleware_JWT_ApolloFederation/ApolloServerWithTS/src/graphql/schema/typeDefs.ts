const typeDefs = `#graphql
   type Book {
    id:Int
    title: String
    authorId:Int
  }
  type Author {
    id:Int,
    name:String,
    age:Int,
    books:[Book]
  }
  type Product{
     id: ID!,
     title: String,
     price: Int,
     likes: Int,
     rating: Int,
     imageUrl: String,
     isAvailable: Boolean,
     description: String,
  }
  type Geo {
    lat:String,
    lng:String
  }
  type Address{
  street: String,
  suite: String,
  city: String,
  zipcode: String,
  geo: Geo
  }
  type Company{
    name:String,
    catchPhrase:String,
    bs:String
  }
  type User{
    id: ID!,
    username: String,
     name: String,
     email: String,
     address: Address,
     phone: String,
     website: String,
     company: Company, 
  }

 type Query {
    books: [Book]
    book(id:ID!):Book
    author(id:Int):Author
    authors:[Author]
    products:[Product]
    product(id:ID!):Product
    users(limit:Int,cursor:ID!):UserFeed
    user(id:ID!):User
    member(id:ID!):Member
  }

  type UserFeed{
    usersFeed:[User]!
    pageInfo:PageInfo
  }
  
  type PageInfo{
    nextPageCursor:ID
    hasnextPage:Boolean
  }

  type Member{
    id:ID!,
    name:String!
    email:String!
    password:String!
  }

  type Mutation{
    addBook(id:Int!,title:String!,authorId:Int):Book
    deleteProduct(id:ID!):Product
    addProduct(id: ID!,
     title: String!,
     price: Int!,
     likes: Int,
     rating: Int,
     imageUrl: String,
     isAvailable: Boolean,
     description: String):Product
     incrementLikes(id:ID!):Product
     login(input:LogInInput): Token

  }

  type Token{
    token:String
  }
  input LogInInput{
    email:String!
    password:String!
  }
`;
export default typeDefs;
