import { useQuery } from "@apollo/client";
import { useEffect, useState } from "react";
import { GET_BOOKS_WITH_TITLES } from "../graphql/queries";
// Using State
// function BooksList() {
//   const { error, loading, data } = useQuery(GET_BOOKS_WITH_TITLES);
//   const [books, setBooks] = useState([]);

//   useEffect(() => {
//     if (!loading) {
//       setBooks(data.books);
//     }
//   }, [data]);

//   let booksToBeCreated = books.map((book: any) => (
//     <li key={book.title}>{book.title}</li>
//   ));
//   return (
//     <div>
//       <ul>{booksToBeCreated}</ul>
//     </div>
//   );
// }

// export default BooksList;

function BooksList() {
  const { error, loading, data } = useQuery(GET_BOOKS_WITH_TITLES);

  if (loading) return <strong>Loading...</strong>;
  if (error) return <strong>Error! ${error.message} </strong>;

  return (
    <div>
      <ul>
        {data.books.map((book: any) => (
          <li key={book.title}>{book.title}</li>
        ))}
      </ul>
    </div>
  );
}

export default BooksList;
