import React, { Component, useEffect, useState } from "react";
import Product from "../product/product.component";
import { useQuery } from "@apollo/client";
import { Get_ALL_PRODUCTS } from "../../graphql/queries";
import ProductModel from "../../models/product.model";

export type ProductsFetchData = {
  products: ProductModel[];
};

export default function ProductList() {
  const { error, loading, data } =
    useQuery<ProductsFetchData>(Get_ALL_PRODUCTS);

  if (loading) return <strong>Loading...</strong>;
  if (error) return <strong>Error! ${error.message}</strong>;
  return (
    <>
      <h1>List Of Products</h1>
      <div className="row">
        {data?.products?.map((product: ProductModel) => (
          <Product key={product.id} productdetails={product} />
        ))}
      </div>
    </>
  );
}
