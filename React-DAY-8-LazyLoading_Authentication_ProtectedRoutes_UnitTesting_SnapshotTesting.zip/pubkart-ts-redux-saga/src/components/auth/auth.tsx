import React, { createContext, ReactNode, useContext, useState } from "react";
import { CurrentUser } from "../../models/currentuser.model";

export type AuthContextType = {
  user: CurrentUser;
  login: (user: CurrentUser) => void;
  logout: () => void;
};

const AuthContext = createContext<AuthContextType | null>(null);

const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState(new CurrentUser());
  const login = (user: CurrentUser) => {
    setUser(user);
  };
  const logout = () => {
    setUser({
      name: "",
      password: "",
      isLoggedIn: false,
    });
  };
  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom Hook - Definition
export const useAuth = () => {
  return useContext(AuthContext);
};

export default AuthProvider;
