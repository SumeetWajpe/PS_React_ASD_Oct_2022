import Enzyme, { shallow } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import App from "./App";

Enzyme.configure({ adapter: new Adapter() });
// test suite
describe("test suite for counter", () => {
  // test case
  it("counter state is set to zero initially !", () => {
    // Arrange -> Act -> Assert
    let appInstance = shallow(<App />); // creates a shallow Instance of App // Arrange
    let initialCount = appInstance.state().count; // Act
    expect(initialCount).toBe(0); // Assert
  });

  it("increments counter on button click", () => {
    let appInstance = shallow(<App />); // creates a shallow Instance of App // Arrange
    let btn = appInstance.find("button"); // any css selector
    btn.simulate("click"); // Act
    let countText = appInstance.find("strong").text();
    expect(countText).toBe("1");
  });
});

// import { render, screen } from "@testing-library/react"; // renderer !
// import App from "./App";

// test("renders learn react link", () => {
//   render(<App />);
//   const linkElement = screen.getByText(/learn react/i);
//   expect(linkElement).toBeInTheDocument();
// });
